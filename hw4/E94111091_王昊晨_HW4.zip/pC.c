#include <stdio.h>
#include <float.h>
#include <math.h>
int main(){
    printf("最大值:%.10e\n",FLT_MAX);
    printf("最小值:%.10e\n",-FLT_MIN);
    float max=FLT_MAX;
    int *f_max=(int*)&max;
    printf("最大值的bit:");
    for(int i=31;i>=0;i--){
        printf("%d",(*f_max>>i)&1);
    }
    printf("\n最小值的bit:");
    float min=-FLT_MIN;
    int *f_min=(int*)&min;
    for(int i=31;i>=0;i--){
        printf("%d",(*f_min>>i)&1);
    }
    printf("\n");
    float nan=NAN;
    int *f_nan=(int*)&nan;
    printf("%f\n",nan);
    printf("nan值的bit:");
    for(int i=31;i>=0;i--){
        printf("%d",(*f_nan>>i)&1);
    }
    printf("\n");
    float inf=INFINITY;
    int *f_inf=(int*)&inf;
    printf("%f\n",inf);
    printf("inf值的bit:");
    for(int i=31;i>=0;i--){
        printf("%d",(*f_inf>>i)&1);
    }
}